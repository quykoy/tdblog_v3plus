<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
<meta charset="UTF-8" />
<title>đang bảo trì</title>
</head>

<body>
	<h2>trang wap đang bảo trì, vui lòng quay lại sau</h2>
</body>
</html>
