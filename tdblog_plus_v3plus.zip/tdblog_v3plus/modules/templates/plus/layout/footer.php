<div id="footer">
    <div class="copyright">
        copyright by Tiến Định<br>&copy; <a href="http://tiendinh.name.vn" title="TDBlog" style="color: rgb(163, 244, 255);">TDblog</a> V3.0 <?php echo date('Y') ?> - <?php echo date('Y')+1 ?><br>
    </div>
    <div class="post_tag">
    	<b>Tags: </b><?php tags($tag); ?><br>
        <a href="<?php echo __SITE_URL; ?>/sitemap.xml" title="sitemap">Sitemap</a>
    </div>
</div>
</body>
</html>

