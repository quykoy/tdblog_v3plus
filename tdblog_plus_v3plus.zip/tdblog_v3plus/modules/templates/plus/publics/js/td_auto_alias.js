    $( "input#title" ).keyup(function() {
	var value = $( this ).val();
	var nodeUrl = $("input#alias");
	var tmp = nodeUrl.val();
	nodeUrl.val(change_alias(value));
	chaneIcon();
    }).keyup();

function chaneIcon()
{
	var nodeCurent = $('i.glyphicon-random');
	nodeCurent.removeClass('glyphicon-random').removeClass('glyphicon');
	nodeCurent.addClass('fa').addClass('fa-spinner').addClass('fa-spin');
	setTimeout(function(){
		nodeCurent = $('i.fa-spin');
		nodeCurent.removeClass('fa-spinner').removeClass('fa').removeClass('fa-spin');
		nodeCurent.addClass('glyphicon').addClass('glyphicon-random');
	}, 1000);
}

function change_alias( alias )
{
    var str = alias;
    str= str.toLowerCase(); 
    str= str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,"a"); 
    str= str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g,"e"); 
    str= str.replace(/ì|í|ị|ỉ|ĩ/g,"i"); 
    str= str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ợ|ở|ỡ|ớ/g,"o"); 
    str= str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g,"u"); 
    str= str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y"); 
    str= str.replace(/đ/g,"d"); 
    str= str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'| |\"|\&|\#|\[|\]|~|$|_/g,"-");
    /* tìm và thay thế các kí tự đặc biệt trong chuỗi sang kí tự - */
    str= str.replace(/-+-/g,"-"); //thay thế 2- thành 1-
    str= str.replace(/^\-+|\-+$/g,""); 
    //cắt bỏ ký tự - ở đầu và cuối chuỗi 
    return str;
}