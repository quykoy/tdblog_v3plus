<?php
show_alert ( 4, array (
		'làm sạch danh sách hot ??' 
) )?>
<div class="item">
	<a
		href="<?php echo base_url(); ?>/admin/manage_blog_host/delete_all/ok"
		title=""> <input type="submit" value="Xác Nhận Xóa" name="delete"
		style="display: inline; margin-left: 41px; margin-right: 10px;">
	</a> <a href="<?php echo base_url(); ?>"><input type="button"
		value="Hủy" style="display: inline; margin-left: 5px; width: 100px;"></a>
</div>