<div class="title_menu">Admin Panel</div>
<div class="wraper">
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-post.png">
        <a href="<?php echo base_url(); ?>/admin/post" title="Đăng Bài Viết Mới"><span>Đăng Bài Viết Mới</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon_leech.png">
        <a href="<?php echo base_url(); ?>/leech" title="Tool Leech"><span>Tool Leech</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-blog-manage.png">
        <a href="<?php echo base_url(); ?>/admin/blog" title="Quản Lý Blog"><span>Cài Đặt Blog</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-manange-category.png">
        <a href="<?php echo base_url(); ?>/admin/category" title="Quản Lý Chuyên Mục"><span>Quản Lý Chuyên Mục</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-block-view.png">
        <a href="<?php echo base_url(); ?>/admin/block_view" title="Quản Lý Khối Hiển Thị"><span>Quản Lý Khối Hiển Thị</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-setting.png">
        <a href="<?php echo base_url(); ?>/admin/general" title="cài đăt chung"><span>Cài Đặt Chung</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/Java.png">
        <a href="<?php echo base_url(); ?>/admin/java" title="cài đăt chung"><span>Cấu hình Java</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-cache.png">
        <a href="<?php echo base_url(); ?>/admin/cache" title="Quản Lý Cache"><span>Quản Lý Cache</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon_profile.png">
        <a href="<?php echo base_url(); ?>/user/change_info" title="Thông tin admin"><span>Thông tin admin</span></a>
    </div>
    <div class="row">
        <img src="<?php echo base_url(); ?>/publics/images/icon-logout.png">
        <a href="<?php echo base_url(); ?>/user/logout" title="Đăng xuất"><span>Đăng Xuất</span></a>
    </div>
</div>