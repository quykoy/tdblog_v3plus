<div class="title_menu">Quản Lý Chuyên Mục</div>
<div class="wraper">
	<div class="row">
		<img src="<?php echo base_url(); ?>/publics/images/icon-add.png"> <a
			href="<?php echo base_url(); ?>/admin/category/create"
			title="Tạo Chuyên Mục Mới"><span>Tạo Chuyên Mục Mới</span></a>
	</div>
	<div class="row">
		<img
			src="<?php echo base_url(); ?>/publics/images/icon-list-category.png">
		<a href="<?php echo base_url(); ?>/admin/category/list"
			title="cài đăt chung"><span>Danh Sách Chuyên Mục</span></a>
	</div>
</div>