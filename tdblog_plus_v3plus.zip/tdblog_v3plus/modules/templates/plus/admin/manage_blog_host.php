<div class="title_menu">Quản lý bài viết hot</div>
<div class="wraper">
	<div class="row2">
		<span><a href="<?php echo base_url(); ?>/blog/hot">Danh sách bài
				viết hot</a></span>
	</div>
	<div class="row2">
		<span><a
			href="<?php echo base_url(); ?>/admin/manage_blog_host/delete_all">Làm
				sạch danh sách hot</a></span>
	</div>
</div>