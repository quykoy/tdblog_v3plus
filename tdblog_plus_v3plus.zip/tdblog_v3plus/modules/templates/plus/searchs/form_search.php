<div class="title_menu">Tìm Kiếm</div>
<div class="wraper" style="text-align: center;">
	<form action="<?php echo base_url().'/search' ?>" method="post">
		<input type="text" name="keyword"
			value="Nhập từ khóa tìm kiếm..."
			onfocus="if(this.value=='Nhập từ khóa tìm kiếm...')this.value='';"
			style="width: 50%; margin-top: 8px;"> <br> <input type="submit"
			name="search" value="Tìm Kiếm" style="margin-top: 8px;">
	</form>
</div>